package com.centrychat.android.data.repository

import com.centrychat.android.BuildConfig
import com.centrychat.android.core.network.CentryChatApi
import com.centrychat.android.data.model.ArticleCardDto
import com.centrychat.android.data.model.ArticleDeleteResponse
import com.centrychat.android.data.model.ArticleDetailDto
import com.centrychat.android.data.model.ArticleInsightsResponse
import com.centrychat.android.data.model.ArticleListResponse
import com.centrychat.android.data.model.ArticleTranslationResponse
import com.centrychat.android.data.model.ArticleUpsertBody
import com.centrychat.android.data.model.ArticleViewResponse
import com.centrychat.android.data.model.CommentDto
import com.centrychat.android.data.model.CommentsResponse
import com.centrychat.android.data.model.RelatedArticlesResponse
import com.centrychat.android.data.model.ShareResponse
import com.centrychat.android.data.model.ToggleLikeResponse
import com.centrychat.android.data.model.safeApiCall

/**
 * Articles repository.
 *
 * Wraps the article list + article detail + article-like + article-comments
 * + article-share + article CRUD + article views + related articles +
 * translation + insights endpoints.
 *
 * Backend contracts (mirrors the web):
 *  - `GET /api/v1/articles`                  → `{ articles: ArticleCardDto[] }` (global)
 *  - `GET /api/v1/users/{username}/articles` → `{ articles: ArticleCardDto[] }` (per-user)
 *  - `GET /api/v1/articles/{id}`             → `{ article: ArticleDetailDto }` (wrapped)
 *  - `POST /api/v1/articles`                 → `{ article: ArticleDetailDto }` (wrapped) — create
 *  - `PATCH /api/v1/articles/{id}`           → `{ article: ArticleDetailDto }` (wrapped) — edit
 *  - `DELETE /api/v1/articles/{id}`           → `{ deleted: true, id }` — delete
 *  - `POST /api/v1/articles/{id}/views`      → `{ recorded, viewCount, rateLimited }` — PUBLIC
 *  - `GET /api/v1/articles/{id}/related`     → `{ articles: RelatedArticleDto[] }` — PUBLIC
 *  - `GET /api/v1/articles/{id}/translation` → `{ translation: ArticleTranslationDto }` — PUBLIC
 *  - `GET /api/v1/articles/{id}/insights`    → author-only
 *  - `POST /api/v1/articles/{id}/like`       → `{ liked, likeCount }`
 *  - `POST /api/v1/articles/{id}/share`      → `{ shared, shareCount }`
 *  - `GET /api/v1/articles/{id}/comments`    → `{ comments, nextCursor, commentCount }`
 *  - `POST /api/v1/articles/{id}/comments`   → `{ comment: CommentDto }` (wrapped)
 *  - `POST /api/v1/article-comments/{id}/like` → `{ liked, likeCount }`
 *
 * ERROR HANDLING: every API call goes through [safeApiCall] which extracts
 * the structured `error.message` from non-2xx responses.
 */
class ArticlesRepository(
    private val api: CentryChatApi,
) {
    private val origin: String = BuildConfig.API_ORIGIN

    /** Fetch a paginated list of published articles. */
    suspend fun getArticles(cursor: String? = null, limit: Int = 10): ArticleListResponse {
        return safeApiCall { api.getArticles(limit = limit, cursor = cursor) }
    }

    /** Fetch a single article by ID (includes the full content body). */
    suspend fun getArticle(id: String): ArticleDetailDto {
        return safeApiCall { api.getArticle(id) }.article
    }

    /**
     * Create a new article. Mirrors POST /api/v1/articles.
     *
     * The backend requires `requireVerifiedUser` — the caller must be
     * logged in with a verified email. Returns the created article
     * (with server-computed readingTime, moderationStatus, etc.).
     *
     * @param body the article fields (title + content required, others optional).
     * @return the created [ArticleDetailDto].
     * @throws com.centrychat.android.data.model.ApiClientError on validation
     *   failure (title too short, content too short, invalid image URL,
     *   blocked domain, moderation BLOCK, rate limit exceeded).
     */
    suspend fun createArticle(body: ArticleUpsertBody): ArticleDetailDto {
        return safeApiCall { api.createArticle(body = body, origin = origin) }.article
    }

    /**
     * Edit an existing article. Mirrors PATCH /api/v1/articles/{id}.
     *
     * The backend checks ownership (authorId === user.id OR admin). All
     * fields in [body] are optional — send only the changed fields.
     * Sending `coverImage = ""` clears the cover; `videoUrl = ""` clears
     * the video; `topicIds = emptyList()` clears all topics.
     *
     * Side effect: if title/content/excerpt changed, the backend
     * invalidates all cached translations for this article.
     *
     * @return the updated [ArticleDetailDto].
     */
    suspend fun updateArticle(id: String, body: ArticleUpsertBody): ArticleDetailDto {
        return safeApiCall { api.updateArticle(id = id, body = body, origin = origin) }.article
    }

    /**
     * Delete an article. Mirrors DELETE /api/v1/articles/{id}.
     *
     * The backend checks ownership (authorId === user.id OR admin). The
     * delete cascades to ArticleLike, ArticleComment (+ nested replies +
     * likes), ArticleView, ArticleInteraction, ArticleTranslation,
     * PlaylistItem. The caller is responsible for navigating the user
     * away from the deleted article's screen (the UI pops the back stack).
     *
     * @return the [ArticleDeleteResponse] with `deleted = true` on success.
     */
    suspend fun deleteArticle(id: String): ArticleDeleteResponse {
        return safeApiCall { api.deleteArticle(id = id, origin = origin) }
    }

    /**
     * Record a view on an article. Mirrors POST /api/v1/articles/{id}/views.
     *
     * PUBLIC endpoint — works for both logged-in users AND anonymous
     * visitors. The backend dedupes by (articleId, userId) for logged-in
     * users OR (articleId, anonymousVisitorId) for anonymous visitors.
     *
     * For anonymous visitors, the backend sets a `cc_visitor` cookie on
     * the response. On Android we send the visitor ID via the
     * `X-Visitor-Id` header (the native equivalent — see VisitorTracker.kt).
     * The backend accepts either the cookie OR the header (header takes
     * precedence — this lets the Android app participate in view tracking
     * without depending on cookie-based session state).
     *
     * Returns `recorded: false` for:
     *   - Duplicate views (user already viewed this article).
     *   - Author self-views (the article's author viewing their own article).
     *   - Bot User-Agents (Googlebot, Bingbot, etc. — not applicable on Android).
     *   - Rate-limited IPs (>60 requests/60s per IP — soft no-op).
     *
     * @param id the article ID.
     * @param visitorId the anonymous visitor ID (from VisitorTracker) —
     *   null when the user is logged in (the backend uses the session
     *   cookie to identify the user).
     * @return the [ArticleViewResponse] with `recorded` + `viewCount`.
     */
    suspend fun recordArticleView(id: String, visitorId: String? = null): ArticleViewResponse {
        return safeApiCall { api.recordArticleView(id = id, visitorId = visitorId) }
    }

    /**
     * Fetch related articles for an article. Mirrors
     * GET /api/v1/articles/{id}/related?limit=5.
     *
     * PUBLIC endpoint — no auth required. The backend uses a scoring
     * algorithm (same author, keyword overlap, same language, recency,
     * engagement, trending) and returns up to 6 candidates with a
     * `reason` field explaining the match.
     *
     * @param id the source article ID.
     * @param limit max results (default 5, clamped 1-6 by backend).
     * @return the [RelatedArticlesResponse] (empty list if no candidates).
     */
    suspend fun getRelatedArticles(id: String, limit: Int = 5): RelatedArticlesResponse {
        return safeApiCall { api.getRelatedArticles(id = id, limit = limit) }
    }

    /**
     * Fetch a translation of an article. Mirrors
     * GET /api/v1/articles/{id}/translation?lang=XX.
     *
     * PUBLIC endpoint — anonymous visitors can request translations.
     * The backend uses GLM-4.6 via z-ai-web-dev-sdk and caches results
     * keyed by (articleId, languageCode) with SHA-256 source hash
     * invalidation (article edits invalidate the cache).
     *
     * @param id the article ID.
     * @param lang the 2-letter ISO 639-1 language code (e.g. "ar", "fr", "es").
     * @return the [ArticleTranslationResponse] with translated title +
     *   content + the language's native name + text direction.
     */
    suspend fun getArticleTranslation(id: String, lang: String): ArticleTranslationResponse {
        return safeApiCall { api.getArticleTranslation(id = id, lang = lang) }
    }

    /**
     * Fetch engagement insights for an article. Mirrors
     * GET /api/v1/articles/{id}/insights.
     *
     * Auth required + ownership check (author or admin) — backend
     * returns 403 Forbidden otherwise.
     *
     * @param id the article ID.
     * @return the [ArticleInsightsResponse] with metrics + audience breakdown.
     */
    suspend fun getArticleInsights(id: String): ArticleInsightsResponse {
        return safeApiCall { api.getArticleInsights(id = id) }
    }

    /** Toggle like on an article. */
    suspend fun toggleLike(id: String): ToggleLikeResponse {
        return safeApiCall { api.toggleArticleLike(id = id, origin = origin) }
    }

    /**
     * Record a SHARE interaction on an article. Mirrors the web's
     * ArticleActions share-dialog behavior.
     *
     * Backend: `POST /api/v1/articles/{id}/share` (see
     * src/app/api/v1/articles/[id]/share/route.ts). Records an
     * ArticleInteraction row + increments the article's shareCount.
     * Returns the server-authoritative shareCount.
     *
     * @param method how the article was shared. "native" (default) for
     *               system-share, "link_copy" for copy-link, etc.
     */
    suspend fun shareArticle(id: String, method: String = "native"): ShareResponse {
        val body = mapOf<String, String?>("method" to method)
        return safeApiCall { api.shareArticle(id = id, body = body, origin = origin) }
    }

    /** Fetch paginated comments for an article (sorted by newest by default). */
    suspend fun getComments(
        articleId: String,
        limit: Int = 50,
    ): CommentsResponse {
        return safeApiCall { api.getArticleComments(id = articleId, limit = limit) }
    }

    /** Create a top-level comment or a reply (when parentCommentId is set). */
    suspend fun createComment(
        articleId: String,
        content: String,
        parentCommentId: String? = null,
    ): CommentDto {
        val body = buildMap {
            put("content", content)
            if (parentCommentId != null) put("parentCommentId", parentCommentId)
        }
        return safeApiCall {
            api.createArticleComment(id = articleId, body = body, origin = origin)
        }
    }

    /** Toggle like on an article comment (or reply). */
    suspend fun toggleCommentLike(commentId: String): ToggleLikeResponse {
        return safeApiCall { api.toggleArticleCommentLike(id = commentId, origin = origin) }
    }

    /** Convenience: fetch the first page of articles as a flat list. */
    suspend fun getFirstPage(limit: Int = 10): List<ArticleCardDto> {
        return getArticles(cursor = null, limit = limit).articles
    }

    /**
     * Fetch a specific user's published articles (and drafts if the
     *  viewer is the author).
     *
     *  Used by the Profile screen's Posts tab (merged with the user's
     *  Posts, mirroring the web's ProfilePosts layout: posts first,
     *  then articles). The global `/api/v1/articles` returns articles
     *  from ALL users — using it on Profile caused the wrong user's
     *  articles to render. This method calls
     *  `/api/v1/users/{username}/articles`, which the backend filters
     *  server-side by author.
     *
     *  @param limit default 50 — matches the backend's hard cap. Use
     *               a smaller value to reduce payload, but you'll get
     *               only the most-recent N articles.
     */
    suspend fun getUserArticles(username: String, limit: Int = 50): List<ArticleCardDto> {
        return safeApiCall { api.getUserArticles(username = username, limit = limit) }.articles
    }
}
