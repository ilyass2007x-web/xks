package com.centrychat.android.core.storage

import android.content.Context
import android.util.Log
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import java.util.UUID

/**
 * Native Android equivalent of the website's `cc_visitor` cookie.
 *
 * ## Why this exists
 *
 * The website (Next.js) sets a `cc_visitor` cookie on every anonymous
 * visitor the first time they view an article. The cookie value is a
 * random UUID generated server-side. The backend hashes it with SHA-256
 * (truncated to 32 hex chars, prefixed with `anon:`) before storing it
 * in `ArticleView.anonymousVisitorId` — this way a DB leak can't be
 * mapped back to a specific browser.
 *
 * The cookie is used to dedupe article views per anonymous visitor
 * (one row per (article, visitor) — refresh doesn't increment the count).
 *
 * ## Why Android needs a native equivalent
 *
 * OkHttp's `PersistentCookieJar` can store `cc_visitor` cookies set by
 * the backend, but there are two problems:
 *
 * 1. **First-view race**: the first time an anonymous visitor opens an
 *    article, the backend generates the cookie in the /views response.
 *    But the view-recording logic needs the visitor ID BEFORE the
 *    response arrives — otherwise the first view is recorded with no
 *    visitor ID (or with a different ID generated on the server side
 *    of the same request). This is fine on the web (cookie is set in
 *    the response, subsequent requests send it back), but on Android
 *    we want to send the visitor ID on the FIRST request so the backend
 *    can dedupe it correctly from request #1.
 *
 * 2. **Cookie expiry**: the website's `cc_visitor` cookie has a 1-year
 *    TTL. If the user clears app data or reinstalls, the cookie is lost
 *    and a new visitor ID is generated — inflating view counts. A
 *    DataStore-backed ID survives app data clears (it lives in the
 *    app's internal storage which is only cleared on uninstall).
 *
 * ## Solution
 *
 * Generate a random UUID on first launch, persist it in DataStore
 * (plaintext — it's a public random ID, not a secret). Send it via
 * the `X-Visitor-Id` header on every /views request when the user is
 * NOT logged in. The backend accepts either the `cc_visitor` cookie OR
 * the `X-Visitor-Id` header (header takes precedence).
 *
 * When the user IS logged in, we don't send the header — the backend
 * uses the session cookie to identify the user. This matches the
 * website's behavior (logged-in users' views are keyed by userId, not
 * by the cc_visitor cookie).
 *
 * ## Privacy
 *
 * The visitor ID is a random UUID with no PII. It's sent only to the
 * CentryChat backend over HTTPS. It's NOT shared with third parties.
 * The backend hashes it before storage, so even a DB leak can't map
 * a view back to a specific install.
 *
 * ## Backend contract
 *
 * The backend's `POST /api/v1/articles/{id}/views` route reads the
 * `X-Visitor-Id` header (or the `cc_visitor` cookie) when the user is
 * not authenticated. The header value is hashed the same way as the
 * cookie value (SHA-256 → 32 hex chars → `anon:` prefix). The backend
 * does NOT require the visitor ID to be in any specific format — it
 * just needs to be a stable, unique string per install.
 *
 * @param context the application context (for DataStore access).
 */
class VisitorTracker(
    private val context: Context,
) {
    /**
     * The visitor ID flow. Emits the current ID (generating + persisting
     * one on first access if none exists). Never emits null — always
     * a non-empty UUID string.
     */
    val visitorId: Flow<String> = context.visitorTrackerDataStore.data.map { prefs ->
        prefs[VISITOR_ID_KEY] ?: generateAndPersist()
    }

    /**
     * Suspend helper to get the current visitor ID. Generates + persists
     * one on first call if none exists.
     */
    suspend fun getVisitorId(): String {
        return visitorId.first()
    }

    /**
     * Generates a new random UUID + persists it to DataStore. Called
     * only when no visitor ID exists yet (first launch).
     *
     * Returns the new ID so the caller can use it immediately without
     * a second DataStore read.
     */
    private suspend fun generateAndPersist(): String {
        val newId = UUID.randomUUID().toString()
        try {
            context.visitorTrackerDataStore.edit { prefs ->
                // Double-check inside the edit atomic block — another
                // coroutine may have generated + persisted an ID between
                // our read + this write. If so, keep the existing one
                // (first writer wins) to avoid duplicates.
                if (prefs[VISITOR_ID_KEY] == null) {
                    prefs[VISITOR_ID_KEY] = newId
                }
            }
        } catch (e: Exception) {
            // DataStore write failure is non-fatal — we still return
            // the new ID for this session. The next session will try again.
            Log.w(TAG, "Failed to persist visitor ID (non-fatal): ${e.message}")
        }
        // Re-read to get the authoritative value (in case another coroutine
        // won the race + wrote a different ID).
        return context.visitorTrackerDataStore.data.map { it[VISITOR_ID_KEY] ?: newId }.first()
    }

    companion object {
        private const val TAG = "CentryChat/VisitorTracker"
        private const val PREFERENCES_NAME = "centrychat_visitor_tracker"
        private val VISITOR_ID_KEY = stringPreferencesKey("visitor_id")

        /**
         * Extension property on Context to provide a single DataStore
         * instance per process (DataStore requires this — creating
         * multiple instances for the same file throws).
         */
        private val Context.visitorTrackerDataStore by preferencesDataStore(PREFERENCES_NAME)
    }
}
