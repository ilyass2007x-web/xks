package com.centrychat.android.feature.post_detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.ArticleDetailDto
import com.centrychat.android.data.model.ArticleTranslationDto
import com.centrychat.android.data.model.CommentDto
import com.centrychat.android.data.model.RelatedArticleDto
import com.centrychat.android.data.repository.ArticlesRepository
import com.centrychat.android.core.storage.VisitorTracker
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * PHASE 1 — ARTICLE PARITY
 *
 * Article detail screen ViewModel — loads a single article + its
 * comment thread, and handles the toggleLike / share / comment / reply
 * / delete / translate / load-related / record-view actions.
 *
 * Mirrors the website's `src/components/articles/article-reading-page.tsx`:
 *   - loadArticle + loadComments in parallel
 *   - toggleLike on the article (server-authoritative likeCount)
 *   - shareArticle (records a SHARE event on the backend)
 *   - sendComment (top-level + reply via parentCommentId)
 *   - toggleCommentLike on individual comments
 *   - recordView on mount (PUBLIC — works for anonymous + logged-in;
 *     uses VisitorTracker for the cc_visitor equivalent)
 *   - loadRelatedArticles (PUBLIC)
 *   - loadTranslation (PUBLIC — GLM-4.6 via z-ai-web-dev-sdk)
 *   - deleteArticle (owner-only — backend checks ownership)
 *
 * Backend contracts (mirrors the website):
 *   - `GET /api/v1/articles/{id}`            → `{ article: ArticleDetailDto }`
 *   - `POST /api/v1/articles/{id}/like`      → `{ liked, likeCount }`
 *   - `POST /api/v1/articles/{id}/share`     → `{ shared, shareCount }`
 *   - `GET /api/v1/articles/{id}/comments`  → `{ comments, nextCursor, commentCount }`
 *   - `POST /api/v1/articles/{id}/comments`  → `{ comment: CommentDto }` (wrapped)
 *   - `POST /api/v1/article-comments/{id}/like` → `{ liked, likeCount }`
 *   - `POST /api/v1/articles/{id}/views`      → `{ recorded, viewCount }` — PUBLIC
 *   - `GET /api/v1/articles/{id}/related`    → `{ articles: RelatedArticleDto[] }` — PUBLIC
 *   - `GET /api/v1/articles/{id}/translation?lang=XX` → `{ translation: ... }` — PUBLIC
 *   - `DELETE /api/v1/articles/{id}`           → `{ deleted: true, id }` — owner-only
 */
class ArticleDetailViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: ArticlesRepository = appContainer.articlesRepository
    private val visitorTracker: VisitorTracker = appContainer.visitorTracker

    private val _state = MutableStateFlow<UiState<ArticleDetailDto>>(UiState.Loading)
    val state: StateFlow<UiState<ArticleDetailDto>> = _state.asStateFlow()

    private val _commentsState = MutableStateFlow<UiState<List<CommentDto>>>(UiState.Loading)
    val commentsState: StateFlow<UiState<List<CommentDto>>> = _commentsState.asStateFlow()

    private val _isSendingComment = MutableStateFlow(false)
    val isSendingComment: StateFlow<Boolean> = _isSendingComment.asStateFlow()

    private val _replyTarget = MutableStateFlow<CommentDto?>(null)
    val replyTarget: StateFlow<CommentDto?> = _replyTarget.asStateFlow()

    // ── Phase 1 new state: related articles ──────────────────────────
    private val _relatedState = MutableStateFlow<UiState<List<RelatedArticleDto>>>(UiState.Loading)
    val relatedState: StateFlow<UiState<List<RelatedArticleDto>>> = _relatedState.asStateFlow()

    // ── Phase 1 new state: translation ──────────────────────────────
    private val _translation = MutableStateFlow<ArticleTranslationDto?>(null)
    val translation: StateFlow<ArticleTranslationDto?> = _translation.asStateFlow()

    private val _isTranslating = MutableStateFlow(false)
    val isTranslating: StateFlow<Boolean> = _isTranslating.asStateFlow()

    private val _translationError = MutableStateFlow<String?>(null)
    val translationError: StateFlow<String?> = _translationError.asStateFlow()

    // ── Phase 1 new state: delete ───────────────────────────────────
    private val _isDeleting = MutableStateFlow(false)
    val isDeleting: StateFlow<Boolean> = _isDeleting.asStateFlow()

    private val _deleted = MutableStateFlow(false)
    val deleted: StateFlow<Boolean> = _deleted.asStateFlow()

    // ── Phase 1 new state: view tracking ────────────────────────────
    private val _viewRecorded = MutableStateFlow(false)
    val viewRecorded: StateFlow<Boolean> = _viewRecorded.asStateFlow()

    fun loadArticle(articleId: String) {
        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                val article = repo.getArticle(articleId)
                _state.value = UiState.Success(article)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = UiState.Error(e.message ?: "Could not load article.")
            }
        }
    }

    fun loadComments(articleId: String) {
        _commentsState.value = UiState.Loading
        viewModelScope.launch {
            try {
                val response = repo.getComments(articleId = articleId, limit = 100)
                _commentsState.value = if (response.comments.isEmpty()) {
                    UiState.Empty
                } else {
                    UiState.Success(response.comments)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _commentsState.value = UiState.Error(e.message ?: "Could not load comments.")
            }
        }
    }

    /**
     * Record a view on the article. Mirrors the website's
     * `src/components/articles/article-reading-page.tsx` lines 246-296
     * (fires once per mount via a `viewFiredRef`).
     *
     * The endpoint is PUBLIC — works for both logged-in users AND
     * anonymous visitors. For anonymous visitors, we send the visitor
     * ID (from VisitorTracker, the native cc_visitor equivalent) via
     * the `X-Visitor-Id` header. For logged-in users, the backend
     * uses the session cookie to identify the user (no header needed).
     *
     * Skipped when:
     *   - The article failed to load (no point recording a view).
     *   - The article is a DRAFT (the backend rejects drafts anyway).
     *   - The viewer is the article's author (self-view exclusion —
     *     the backend also enforces this, but we skip client-side to
     *     save a network round-trip, mirroring the website).
     */
    fun recordView(articleId: String) {
        if (_viewRecorded.value) return // fire-once per ViewModel instance
        val article = (_state.value as? UiState.Success)?.data ?: return
        if (article.status != "PUBLISHED") return // drafts don't count
        // The backend checks authorId === user.id; we can't know the
        // current user ID here without an extra API call, so we let
        // the backend handle author self-view exclusion. This matches
        // the website's behavior (it also makes the call + lets the
        // backend return recorded: false).
        viewModelScope.launch {
            try {
                val visitorId = visitorTracker.getVisitorId()
                val result = repo.recordArticleView(articleId, visitorId = visitorId)
                if (result.recorded) {
                    _viewRecorded.value = true
                    // Update the article's viewCount in the UI.
                    val current = (_state.value as? UiState.Success)?.data ?: return@launch
                    _state.value = UiState.Success(
                        current.copy(viewCount = result.viewCount)
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // View tracking must NEVER break reading — silent.
            }
        }
    }

    /**
     * Load related articles. Mirrors `GET /api/v1/articles/{id}/related`.
     * PUBLIC endpoint — no auth required.
     *
     * The backend uses a scoring algorithm (same author, keyword overlap,
     * same language, recency, engagement, trending) and returns up to 6
     * candidates. Empty list (not error) when no candidates are available.
     */
    fun loadRelatedArticles(articleId: String) {
        _relatedState.value = UiState.Loading
        viewModelScope.launch {
            try {
                val response = repo.getRelatedArticles(articleId)
                _relatedState.value = if (response.articles.isEmpty()) {
                    UiState.Empty
                } else {
                    UiState.Success(response.articles)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // Related articles must NEVER break reading — silent empty.
                _relatedState.value = UiState.Empty
            }
        }
    }

    /**
     * Translate the article to the given language. Mirrors
     * `GET /api/v1/articles/{id}/translation?lang=XX`.
     * PUBLIC endpoint — anonymous visitors can request translations.
     *
     * The backend uses GLM-4.6 via z-ai-web-dev-sdk and caches results.
     * Returns `fromCache: true` when serving from cache (instant).
     *
     * @param articleId the article ID.
     * @param langCode 2-letter ISO 639-1 language code (e.g. "ar", "fr", "es").
     */
    fun translateArticle(articleId: String, langCode: String) {
        if (_isTranslating.value) return
        _isTranslating.value = true
        _translationError.value = null
        viewModelScope.launch {
            try {
                val response = repo.getArticleTranslation(articleId, lang = langCode)
                _translation.value = response.translation
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _translationError.value = "Unable to translate this article right now. Please try again."
            } finally {
                _isTranslating.value = false
            }
        }
    }

    /** Clear the current translation (revert to original content). */
    fun clearTranslation() {
        _translation.value = null
        _translationError.value = null
    }

    /**
     * Delete the article. Mirrors DELETE /api/v1/articles/{id}.
     * Owner-only — backend checks `articleId === user.id OR admin`.
     *
     * On success, sets [deleted] which the screen observes to navigate
     * away (pop back stack to the previous screen, typically the author's
     * profile or the feed).
     *
     * @param articleId the article ID to delete.
     */
    fun deleteArticle(articleId: String) {
        if (_isDeleting.value) return
        _isDeleting.value = true
        viewModelScope.launch {
            try {
                repo.deleteArticle(articleId)
                _deleted.value = true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // Best-effort — the UI shows a toast with the error.
                _translationError.value = e.message ?: "Could not delete article."
            } finally {
                _isDeleting.value = false
            }
        }
    }

    fun toggleLike(articleId: String) {
        viewModelScope.launch {
            try {
                val result = repo.toggleLike(articleId)
                val current = (_state.value as? UiState.Success)?.data ?: return@launch
                _state.value = UiState.Success(
                    current.copy(isLiked = result.liked, likeCount = result.likeCount)
                )
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // best-effort
            }
        }
    }

    /**
     * Record a SHARE interaction on the article. Mirrors the web's
     * ArticleActions share-dialog behavior.
     */
    fun shareArticle(articleId: String) {
        viewModelScope.launch {
            try {
                val result = repo.shareArticle(articleId, method = "native")
                val current = (_state.value as? UiState.Success)?.data ?: return@launch
                _state.value = UiState.Success(
                    current.copy(shareCount = result.shareCount)
                )
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // best-effort — share-tracking failure is non-fatal
            }
        }
    }

    fun toggleCommentLike(commentId: String) {
        viewModelScope.launch {
            try {
                val result = repo.toggleCommentLike(commentId)
                val current = (_commentsState.value as? UiState.Success)?.data ?: return@launch
                val updated = current.map { c ->
                    if (c.id == commentId) {
                        c.copy(isLiked = result.liked, likeCount = result.likeCount)
                    } else c
                }
                _commentsState.value = UiState.Success(updated)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
                // best-effort
            }
        }
    }

    fun sendComment(articleId: String, content: String, parentCommentId: String? = null) {
        if (content.isBlank() || _isSendingComment.value) return
        viewModelScope.launch {
            _isSendingComment.value = true
            try {
                val newComment = repo.createComment(
                    articleId = articleId,
                    content = content,
                    parentCommentId = parentCommentId,
                )
                val current = (_commentsState.value as? UiState.Success)?.data
                if (current != null) {
                    if (parentCommentId != null) {
                        // Insert as a reply to the parent comment.
                        val updated = current.map { c ->
                            if (c.id == parentCommentId) {
                                c.copy(replies = c.replies + newComment)
                            } else c
                        }
                        _commentsState.value = UiState.Success(updated)
                    } else {
                        // Insert as a new top-level comment.
                        _commentsState.value = UiState.Success(listOf(newComment) + current)
                    }
                }
                _replyTarget.value = null
                // Update the article's comment count
                val article = (_state.value as? UiState.Success)?.data
                if (article != null) {
                    _state.value = UiState.Success(article.copy(commentCount = article.commentCount + 1))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                // best-effort — the user can retry
            } finally {
                _isSendingComment.value = false
            }
        }
    }

    fun setReplyTarget(comment: CommentDto?) {
        _replyTarget.value = comment
    }
}
