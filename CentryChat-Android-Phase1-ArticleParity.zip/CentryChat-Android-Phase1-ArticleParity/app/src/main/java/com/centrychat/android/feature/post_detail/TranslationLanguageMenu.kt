package com.centrychat.android.feature.post_detail

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * PHASE 1 — ARTICLE PARITY
 *
 * Translation language selector menu. Mirrors the website's
 * `src/components/articles/language-selector.tsx` (desktop Popover +
 * mobile Sheet → Android DropdownMenu).
 *
 * Shows the supported languages (subset of the website's 36 languages —
 * the most popular 7 + a few more for the mobile UX). The "Original"
 * option at the top resets the content to the original language.
 *
 * The actual translation is performed by the backend (GLM-4.6 via
 * z-ai-web-dev-sdk, cached per (articleId, languageCode) with SHA-256
 * source hash invalidation). This menu just selects the language code
 * and calls [onLanguageSelected].
 *
 * @param expanded whether the menu is visible.
 * @param onDismiss called when the menu should close.
 * @param onLanguageSelected called with the language code (or "original"
 *   to reset to the source language).
 */
@Composable
fun TranslationLanguageMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    onLanguageSelected: (String) -> Unit,
) {
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        modifier = Modifier.heightIn(max = 400.dp),
    ) {
        // "Original" — resets to source content.
        DropdownMenuItem(
            text = {
                Column {
                    Text(
                        text = "Original",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                    )
                    Text(
                        text = "Show the article in its original language",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            },
            onClick = { onLanguageSelected("original") },
        )
        // Popular languages (subset of the website's 36 — the 7 most-used
        // per the website's language-selector.tsx "Popular" section).
        for (lang in POPULAR_LANGUAGES) {
            DropdownMenuItem(
                text = {
                    Column {
                        Text(
                            text = lang.nativeName,
                            style = MaterialTheme.typography.bodyLarge,
                        )
                        Text(
                            text = "${lang.englishName} (${lang.code})${if (lang.dir == "rtl") " · RTL" else ""}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                onClick = { onLanguageSelected(lang.code) },
            )
        }
        // Other languages (a curated subset — the website has 36, we
        // surface the next 8 most common to keep the menu scrollable).
        Text(
            text = "Other languages",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(8.dp),
            fontWeight = FontWeight.SemiBold,
        )
        for (lang in OTHER_LANGUAGES) {
            DropdownMenuItem(
                text = {
                    Column {
                        Text(
                            text = lang.nativeName,
                            style = MaterialTheme.typography.bodyLarge,
                        )
                        Text(
                            text = "${lang.englishName} (${lang.code})${if (lang.dir == "rtl") " · RTL" else ""}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                },
                onClick = { onLanguageSelected(lang.code) },
            )
        }
    }
}

private data class Language(val code: String, val nativeName: String, val englishName: String, val dir: String)

// Mirrors the website's src/lib/articles/languages.ts (subset for mobile UX).
private val POPULAR_LANGUAGES = listOf(
    Language("en", "English", "English", "ltr"),
    Language("ar", "العربية", "Arabic", "rtl"),
    Language("fr", "Français", "French", "ltr"),
    Language("es", "Español", "Spanish", "ltr"),
    Language("de", "Deutsch", "German", "ltr"),
    Language("pt", "Português", "Portuguese", "ltr"),
    Language("it", "Italiano", "Italian", "ltr"),
)

private val OTHER_LANGUAGES = listOf(
    Language("ru", "Русский", "Russian", "ltr"),
    Language("zh", "中文", "Chinese", "ltr"),
    Language("ja", "日本語", "Japanese", "ltr"),
    Language("ko", "한국어", "Korean", "ltr"),
    Language("tr", "Türkçe", "Turkish", "ltr"),
    Language("hi", "हिन्दी", "Hindi", "ltr"),
    Language("fa", "فارسی", "Persian", "rtl"),
    Language("ur", "اردو", "Urdu", "rtl"),
)
