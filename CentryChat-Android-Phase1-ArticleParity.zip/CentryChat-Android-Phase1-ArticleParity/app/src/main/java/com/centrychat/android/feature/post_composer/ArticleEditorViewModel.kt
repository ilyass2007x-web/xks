package com.centrychat.android.feature.post_composer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.ArticleDetailDto
import com.centrychat.android.data.model.ArticleUpsertBody
import com.centrychat.android.data.repository.ArticlesRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * PHASE 1 — ARTICLE PARITY
 *
 * ViewModel for the article editor screen (create + edit).
 *
 * Mirrors the website's `src/components/articles/article-editor.tsx`:
 *   - Two modes: create (no `articleId`) or edit (`articleId` passed in).
 *   - Fields: title, content, excerpt, coverImage URL, videoUrl URL,
 *     status (PUBLISHED | DRAFT), showCoverInArticle toggle.
 *   - Validation mirrors the website's client-side validation (title 3-200
 *     chars, content min 10 chars, excerpt max 300 chars).
 *   - On create: POST /api/v1/articles → navigate to the new article.
 *   - On edit: PATCH /api/v1/articles/{id} → navigate back / pop stack.
 *
 * The website's editor is a plain `<Textarea>` (no rich text — confirmed
 * by the website audit). The Android editor uses the same plain-text
 * input. Users who want HTML formatting can type HTML tags directly
 * (they're rendered by ArticleHtmlRenderer on the detail screen).
 *
 * ## Why no rich text editor library
 *
 * The website doesn't use one (plain `<Textarea>`). Adding a rich text
 * editor library would:
 *   - Increase APK size by ~500 KB-2 MB.
 *   - Create a parity gap (the website doesn't support rich text editing,
 *     so articles edited on Android would have formatting the website
 *     couldn't edit).
 *   - Add a maintenance burden (rich text libraries are complex + have
 *     many bugs around selection, IME, copy/paste, etc.).
 *
 * Plain text input matches the website exactly. Users who want HTML
 * can type it directly — the renderer on the detail screen handles it.
 */
class ArticleEditorViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: ArticlesRepository = appContainer.articlesRepository

    /** The article being edited (null in create mode). */
    private val _editingArticle = MutableStateFlow<ArticleDetailDto?>(null)
    val editingArticle: StateFlow<ArticleDetailDto?> = _editingArticle.asStateFlow()

    /** Form field state. */
    val title = MutableStateFlow("")
    val content = MutableStateFlow("")
    val excerpt = MutableStateFlow("")
    val coverImage = MutableStateFlow("")
    val videoUrl = MutableStateFlow("")
    val status = MutableStateFlow("PUBLISHED") // or "DRAFT"
    val showCoverInArticle = MutableStateFlow(true)

    /** True while loading an existing article for edit, or while saving. */
    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    /** True while submitting (create/update). */
    private val _isSaving = MutableStateFlow(false)
    val isSaving: StateFlow<Boolean> = _isSaving.asStateFlow()

    /** One-shot error message (null = no error). Cleared on next field edit. */
    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error.asStateFlow()

    /** The saved article (set after successful create/update). Triggers navigation. */
    private val _savedArticle = MutableStateFlow<ArticleDetailDto?>(null)
    val savedArticle: StateFlow<ArticleDetailDto?> = _savedArticle.asStateFlow()

    /**
     * Load an existing article for editing. Called when the editor opens
     * in edit mode (articleId != null).
     */
    fun loadArticleForEdit(articleId: String) {
        _isLoading.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                val article = repo.getArticle(articleId)
                _editingArticle.value = article
                title.value = article.title
                content.value = article.content
                excerpt.value = article.excerpt ?: ""
                coverImage.value = article.coverImage ?: ""
                videoUrl.value = article.videoUrl ?: ""
                status.value = article.status
                showCoverInArticle.value = article.showCoverInArticle
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _error.value = e.message ?: "Could not load article for editing."
            } finally {
                _isLoading.value = false
            }
        }
    }

    /**
     * Validate the form + submit (create or update).
     *
     * Mirrors the website's validation:
     *   - title: trim, 3-200 chars.
     *   - content: trim, min 10 chars.
     *   - excerpt: trim, max 300 chars (server slices, but we validate
     *     client-side for instant feedback).
     *   - status: "PUBLISHED" or "DRAFT".
     *
     * On success, sets [savedArticle] which the screen observes to
     * navigate away.
     *
     * @param asDraft if true, overrides the status field to "DRAFT".
     *   Mirrors the website's "Save as draft" button.
     */
    fun submit(asDraft: Boolean = false) {
        // ── Client-side validation (mirrors website's article-editor.tsx:108-135) ──
        val trimmedTitle = title.value.trim()
        val trimmedContent = content.value.trim()
        val trimmedExcerpt = excerpt.value.trim()

        if (trimmedTitle.length !in 3..200) {
            _error.value = "Title must be 3-200 characters."
            return
        }
        if (trimmedContent.length < 10) {
            _error.value = "Content must be at least 10 characters."
            return
        }
        if (trimmedExcerpt.length > 300) {
            _error.value = "Excerpt must be at most 300 characters."
            return
        }

        val finalStatus = if (asDraft) "DRAFT" else status.value.ifBlank { "DRAFT" }

        val body = ArticleUpsertBody(
            title = trimmedTitle,
            content = trimmedContent,
            excerpt = trimmedExcerpt.ifBlank { null },
            coverImage = coverImage.value.trim().ifBlank { null },
            videoUrl = videoUrl.value.trim().ifBlank { null },
            status = finalStatus,
            showCoverInArticle = showCoverInArticle.value,
        )

        _isSaving.value = true
        _error.value = null
        viewModelScope.launch {
            try {
                val saved = if (_editingArticle.value != null) {
                    repo.updateArticle(_editingArticle.value!!.id, body)
                } else {
                    repo.createArticle(body)
                }
                _savedArticle.value = saved
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _error.value = e.message ?: "Could not save article."
            } finally {
                _isSaving.value = false
            }
        }
    }

    /** Clear the one-shot error (called when the user edits a field). */
    fun clearError() {
        _error.value = null
    }

    /** Consume the saved article event (called after navigation). */
    fun consumeSavedArticle() {
        _savedArticle.value = null
    }
}
