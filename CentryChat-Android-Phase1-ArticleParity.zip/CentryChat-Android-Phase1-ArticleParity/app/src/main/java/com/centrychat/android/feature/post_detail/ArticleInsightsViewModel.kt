package com.centrychat.android.feature.post_detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.centrychat.android.core.AppContainer
import com.centrychat.android.core.util.UiState
import com.centrychat.android.data.model.ArticleInsightsResponse
import com.centrychat.android.data.repository.ArticlesRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * PHASE 1 — ARTICLE PARITY
 *
 * ViewModel for the article insights screen (author-only).
 *
 * Mirrors the website's `src/components/articles/article-insights.tsx` +
 * `GET /api/v1/articles/{id}/insights` (author-only — backend returns
 * 403 Forbidden if the viewer isn't the author or an admin).
 *
 * Returns engagement metrics:
 *   - uniqueViews, likes, comments, shares, engagementRate.
 *   - audience breakdown (followerViews vs nonFollowerViews).
 *   - trafficSources (always null on backend — placeholder for future).
 *
 * The screen renders the metrics as cards in a grid + an audience
 * breakdown bar. An empty state is shown when all metrics are 0.
 */
class ArticleInsightsViewModel(
    appContainer: AppContainer,
) : ViewModel() {

    private val repo: ArticlesRepository = appContainer.articlesRepository

    private val _state = MutableStateFlow<UiState<ArticleInsightsResponse>>(UiState.Loading)
    val state: StateFlow<UiState<ArticleInsightsResponse>> = _state.asStateFlow()

    fun loadInsights(articleId: String) {
        _state.value = UiState.Loading
        viewModelScope.launch {
            try {
                val insights = repo.getArticleInsights(articleId)
                _state.value = UiState.Success(insights)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _state.value = UiState.Error(e.message ?: "Could not load insights.")
            }
        }
    }
}
