package com.centrychat.android.feature.post_detail

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * PHASE 1 — ARTICLE PARITY
 *
 * Unit tests for [parseHtml] — the HTML parsing + sanitization logic
 * used by [ArticleHtmlRenderer].
 *
 * These tests verify:
 *   - Plain text content (no HTML tags) is rendered as a single
 *     PlainText block (matches the website's `whitespace-pre-wrap`).
 *   - HTML content is parsed into the correct block structure
 *     (Heading, Paragraph, ListBlock, Blockquote, Code, Image, Divider, Table).
 *   - XSS vectors (`<script>`, `on*` attributes, `javascript:` URLs,
 *     `<iframe>`) are stripped by Jsoup's Safelist.relaxed.
 *   - Empty content produces an empty block list (no crash).
 *   - Invalid/malformed HTML is handled gracefully (no crash, falls
 *     back to plain text).
 *
 * The renderer's Compose rendering (Text, ClickableText, AsyncImage,
 * etc.) is NOT tested here — it requires a Compose UI test environment.
 * The block model + parsing logic is pure Kotlin + testable in unit tests.
 */
class ArticleHtmlRendererTest {

    // ── Plain text fallback ─────────────────────────────────────────────

    @Test
    fun `plain text content returns single PlainText block`() {
        val content = "This is a plain text article.\nNo HTML tags here."
        val blocks = parseHtml(content)

        assertEquals(1, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.PlainText)
        assertEquals(content, (blocks[0] as HtmlBlock.PlainText).text)
    }

    @Test
    fun `content with no angle brackets is treated as plain text`() {
        val content = "Just some words without any markup."
        val blocks = parseHtml(content)

        assertEquals(1, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.PlainText)
    }

    // ── Empty content ───────────────────────────────────────────────────

    @Test
    fun `empty content returns empty block list`() {
        val blocks = parseHtml("")
        assertTrue(blocks.isEmpty())
    }

    // ── Headings ────────────────────────────────────────────────────────

    @Test
    fun `parses h1 h2 h3 headings`() {
        val content = "<h1>Title</h1><h2>Subtitle</h2><h3>Section</h3>"
        val blocks = parseHtml(content)

        assertEquals(3, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.Heading)
        assertEquals(1, (blocks[0] as HtmlBlock.Heading).level)
        assertEquals("Title", (blocks[0] as HtmlBlock.Heading).text.toString())
        assertTrue(blocks[1] is HtmlBlock.Heading)
        assertEquals(2, (blocks[1] as HtmlBlock.Heading).level)
        assertTrue(blocks[2] is HtmlBlock.Heading)
        assertEquals(3, (blocks[2] as HtmlBlock.Heading).level)
    }

    // ── Paragraphs ──────────────────────────────────────────────────────

    @Test
    fun `parses paragraphs`() {
        val content = "<p>First paragraph.</p><p>Second paragraph.</p>"
        val blocks = parseHtml(content)

        assertEquals(2, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.Paragraph)
        assertEquals("First paragraph.", (blocks[0] as HtmlBlock.Paragraph).text.toString())
        assertEquals("Second paragraph.", (blocks[1] as HtmlBlock.Paragraph).text.toString())
    }

    @Test
    fun `parses paragraph with bold and italic inline`() {
        val content = "<p>This is <strong>bold</strong> and <em>italic</em> text.</p>"
        val blocks = parseHtml(content)

        assertEquals(1, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.Paragraph)
        val text = (blocks[0] as HtmlBlock.Paragraph).text.toString()
        assertEquals("This is bold and italic text.", text)
    }

    // ── Lists ───────────────────────────────────────────────────────────

    @Test
    fun `parses unordered list`() {
        val content = "<ul><li>Item 1</li><li>Item 2</li><li>Item 3</li></ul>"
        val blocks = parseHtml(content)

        assertEquals(1, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.ListBlock)
        val list = blocks[0] as HtmlBlock.ListBlock
        assertFalse(list.ordered)
        assertEquals(3, list.items.size)
        assertEquals("Item 1", list.items[0].text.toString())
        assertEquals("Item 3", list.items[2].text.toString())
    }

    @Test
    fun `parses ordered list`() {
        val content = "<ol><li>First</li><li>Second</li></ol>"
        val blocks = parseHtml(content)

        assertEquals(1, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.ListBlock)
        val list = blocks[0] as HtmlBlock.ListBlock
        assertTrue(list.ordered)
        assertEquals(2, list.items.size)
    }

    // ── Blockquote ──────────────────────────────────────────────────────

    @Test
    fun `parses blockquote`() {
        val content = "<blockquote>This is a quote.</blockquote>"
        val blocks = parseHtml(content)

        assertEquals(1, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.Blockquote)
        assertEquals("This is a quote.", (blocks[0] as HtmlBlock.Blockquote).text.toString())
    }

    // ── Code blocks ────────────────────────────────────────────────────

    @Test
    fun `parses pre code block`() {
        val content = "<pre>val x = 42\nprintln(x)</pre>"
        val blocks = parseHtml(content)

        assertEquals(1, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.Code)
        val code = blocks[0] as HtmlBlock.Code
        assertFalse(code.inline)
        assertTrue(code.text.contains("val x = 42"))
    }

    // ── Images ──────────────────────────────────────────────────────────

    @Test
    fun `parses image with src and alt`() {
        val content = """<img src="https://example.com/img.png" alt="An image" />"""
        val blocks = parseHtml(content)

        assertEquals(1, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.Image)
        val img = blocks[0] as HtmlBlock.Image
        assertEquals("https://example.com/img.png", img.src)
        assertEquals("An image", img.alt)
    }

    // ── Horizontal divider ──────────────────────────────────────────────

    @Test
    fun `parses hr divider`() {
        val content = "<p>Before</p><hr><p>After</p>"
        val blocks = parseHtml(content)

        // Jsoup's Safelist.relaxed preserves <hr> tags. We should get
        // 3 blocks: Paragraph, Divider, Paragraph.
        assertEquals(3, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.Paragraph)
        assertTrue(blocks[1] is HtmlBlock.Divider)
        assertTrue(blocks[2] is HtmlBlock.Paragraph)
    }

    // ── Tables ──────────────────────────────────────────────────────────

    @Test
    fun `parses table with header and body`() {
        val content = """
            <table>
              <thead>
                <tr><th>Name</th><th>Age</th></tr>
              </thead>
              <tbody>
                <tr><td>Alice</td><td>30</td></tr>
                <tr><td>Bob</td><td>25</td></tr>
              </tbody>
            </table>
        """.trimIndent()
        val blocks = parseHtml(content)

        assertEquals(1, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.Table)
        val table = blocks[0] as HtmlBlock.Table
        assertEquals(3, table.rows.size)
        assertEquals(2, table.rows[0].cells.size)
        assertEquals("Name", table.rows[0].cells[0].text.toString())
        assertEquals("Alice", table.rows[1].cells[0].text.toString())
    }

    // ── XSS sanitization ───────────────────────────────────────────────

    @Test
    fun `strips script tags`() {
        val content = "<p>Hello</p><script>alert('xss')</script><p>World</p>"
        val blocks = parseHtml(content)

        // The <script> tag is stripped by Jsoup's Safelist.relaxed.
        assertEquals(2, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.Paragraph)
        assertEquals("Hello", (blocks[0] as HtmlBlock.Paragraph).text.toString())
        assertEquals("World", (blocks[1] as HtmlBlock.Paragraph).text.toString())
    }

    @Test
    fun `strips on* event handler attributes`() {
        // The onclick attribute is stripped — the link is still rendered
        // but as a plain link (no JS execution on click).
        val content = """<p><a href="https://example.com" onclick="alert('xss')">Link</a></p>"""
        val blocks = parseHtml(content)

        assertEquals(1, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.Paragraph)
        val text = (blocks[0] as HtmlBlock.Paragraph).text.toString()
        assertEquals("Link", text)
    }

    @Test
    fun `strips iframe tags`() {
        val content = "<p>Before</p><iframe src=\"https://evil.com\"></iframe><p>After</p>"
        val blocks = parseHtml(content)

        // The <iframe> is stripped by Safelist.relaxed.
        assertEquals(2, blocks.size)
        assertEquals("Before", (blocks[0] as HtmlBlock.Paragraph).text.toString())
        assertEquals("After", (blocks[1] as HtmlBlock.Paragraph).text.toString())
    }

    // ── Mixed content ──────────────────────────────────────────────────

    @Test
    fun `parses mixed content with multiple block types`() {
        val content = """
            <h1>Title</h1>
            <p>Intro paragraph.</p>
            <ul><li>Item 1</li><li>Item 2</li></ul>
            <blockquote>A quote.</blockquote>
            <pre>code block</pre>
            <hr>
            <p>Final paragraph.</p>
        """.trimIndent()
        val blocks = parseHtml(content)

        // Verify each expected block type is present (order-independent,
        // count may vary due to Jsoup's whitespace handling between blocks).
        assertTrue("Should produce at least 5 blocks", blocks.size >= 5)
        assertTrue("Should contain a Heading", blocks.any { it is HtmlBlock.Heading })
        assertTrue("Should contain a Paragraph", blocks.any { it is HtmlBlock.Paragraph })
        assertTrue("Should contain a ListBlock", blocks.any { it is HtmlBlock.ListBlock })
        assertTrue("Should contain a Blockquote", blocks.any { it is HtmlBlock.Blockquote })
        assertTrue("Should contain a Code block", blocks.any { it is HtmlBlock.Code })
        assertTrue("Should contain a Divider", blocks.any { it is HtmlBlock.Divider })
    }

    // ── Malformed HTML ─────────────────────────────────────────────────

    @Test
    fun `handles unclosed tags gracefully`() {
        val content = "<p>Unclosed paragraph<p>Second paragraph</p>"
        val blocks = parseHtml(content)

        // Jsoup auto-closes unclosed tags — should produce 2 paragraphs.
        assertTrue(blocks.isNotEmpty())
    }

    // ── Inline link annotations ──────────────────────────────────────

    @Test
    fun `link text is preserved with URL annotation`() {
        val content = """<p>Visit <a href="https://example.com">our site</a> for more.</p>"""
        val blocks = parseHtml(content)

        assertEquals(1, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.Paragraph)
        val para = blocks[0] as HtmlBlock.Paragraph
        val text = para.text.toString()
        assertEquals("Visit our site for more.", text)
        // Verify the URL annotation was added at the link's character range.
        val urlAnnotations = para.text.getStringAnnotations("URL", 0, text.length)
        assertTrue(urlAnnotations.isNotEmpty())
        assertEquals("https://example.com", urlAnnotations[0].item)
    }

    // ── RTL content (Arabic) ──────────────────────────────────────────

    @Test
    fun `parses Arabic RTL content`() {
        // Real article content from the captured backend response.
        val content = "<h1>العملات الرقمية ومستقبل الاقتصاد</h1><p>المقدمة...</p>"
        val blocks = parseHtml(content)

        assertEquals(2, blocks.size)
        assertTrue(blocks[0] is HtmlBlock.Heading)
        assertEquals("العملات الرقمية ومستقبل الاقتصاد", (blocks[0] as HtmlBlock.Heading).text.toString())
        assertTrue(blocks[1] is HtmlBlock.Paragraph)
        assertEquals("المقدمة...", (blocks[1] as HtmlBlock.Paragraph).text.toString())
    }
}
