package com.centrychat.android.data.model

import kotlinx.serialization.json.Json
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * PHASE 1 — ARTICLE PARITY
 *
 * Unit tests for the new Phase 1 article DTOs (create/edit/delete/views/
 * related/translation/insights). Verifies that kotlinx-serialization
 * correctly deserializes the backend's response shapes into the new
 * wrapper types, and that the wrappers' inner fields are accessible.
 *
 * The JSON samples mirror the shapes documented in the website audit:
 *   - POST   /api/v1/articles            → { article: ArticleDetailDto }
 *   - PATCH  /api/v1/articles/{id}       → { article: ArticleDetailDto }
 *   - DELETE /api/v1/articles/{id}        → { deleted: true, id }
 *   - POST   /api/v1/articles/{id}/views  → { recorded, viewCount, rateLimited }
 *   - GET    /api/v1/articles/{id}/related → { articles: RelatedArticleDto[] }
 *   - GET    /api/v1/articles/{id}/translation → { translation: ArticleTranslationDto }
 *   - GET    /api/v1/articles/{id}/insights → { article, metrics, audience }
 *
 * All samples use the same Json configuration as RetrofitFactory.kt
 * (ignoreUnknownKeys, explicitNulls=false, coerceInputValues, isLenient).
 */
class ArticleParityDtoTest {

    private val json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        coerceInputValues = true
        isLenient = true
        encodeDefaults = true
    }

    // ── Article create response ────────────────────────────────────────

    @Test
    fun `deserializes article create response with data-dot-article wrapper`() {
        val raw = """
            {"ok":true,"data":{"article":{"id":"new-art-1","title":"My new article","content":"<p>Hello world</p>","excerpt":"Hello","coverImage":null,"videoUrl":null,"showCoverInArticle":true,"adsEnabled":true,"status":"PUBLISHED","moderationStatus":"APPROVED","publishedAt":"2026-10-04T09:00:00.000Z","readingTime":1,"createdAt":"2026-10-04T09:00:00.000Z","updatedAt":"2026-10-04T09:00:00.000Z","author":{"id":"u1","fullName":"Alice","username":"alice","isVerified":false},"likeCount":0,"commentCount":0,"viewCount":0,"shareCount":0,"isLiked":false,"topicIds":[]}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ArticleUpsertResponse>>(raw)

        assertTrue(response.ok)
        assertNotNull(response.data)
        val article = response.data!!.article
        assertEquals("new-art-1", article.id)
        assertEquals("My new article", article.title)
        assertEquals("<p>Hello world</p>", article.content)
        assertEquals("alice", article.author.username)
        assertEquals("PUBLISHED", article.status)
        assertEquals(0L, article.likeCount)
    }

    // ── Article update response (same shape as create) ─────────────────

    @Test
    fun `deserializes article update response with updated fields`() {
        val raw = """
            {"ok":true,"data":{"article":{"id":"art-1","title":"Updated title","content":"<p>Updated content</p>","excerpt":null,"coverImage":"https://example.com/img.png","videoUrl":null,"showCoverInArticle":true,"adsEnabled":true,"status":"PUBLISHED","moderationStatus":"APPROVED","publishedAt":"2026-08-09T23:39:20.253Z","readingTime":2,"createdAt":"2026-08-09T23:39:20.254Z","updatedAt":"2026-10-04T10:00:00.000Z","author":{"id":"u1","fullName":"Alice","username":"alice","isVerified":false},"likeCount":5,"commentCount":2,"viewCount":42,"shareCount":1,"isLiked":true,"topicIds":["t1","t2"]}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ArticleUpsertResponse>>(raw)

        assertTrue(response.ok)
        val article = response.data!!.article
        assertEquals("Updated title", article.title)
        assertEquals("<p>Updated content</p>", article.content)
        assertEquals("https://example.com/img.png", article.coverImage)
        assertEquals(2, article.readingTime)
        assertEquals(42L, article.viewCount)
        assertEquals(true, article.isLiked)
        assertEquals(listOf("t1", "t2"), article.topicIds)
    }

    // ── Article delete response ─────────────────────────────────────────

    @Test
    fun `deserializes article delete response`() {
        val raw = """
            {"ok":true,"data":{"deleted":true,"id":"art-1"}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ArticleDeleteResponse>>(raw)

        assertTrue(response.ok)
        assertEquals(true, response.data!!.deleted)
        assertEquals("art-1", response.data!!.id)
    }

    @Test
    fun `deserializes article delete response with missing id field`() {
        // The id field is nullable — some backends omit it. Verify we
        // don't crash + the deleted flag is still readable.
        val raw = """
            {"ok":true,"data":{"deleted":true}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ArticleDeleteResponse>>(raw)

        assertTrue(response.ok)
        assertEquals(true, response.data!!.deleted)
        assertNull(response.data!!.id)
    }

    // ── Article view tracking response ──────────────────────────────────

    @Test
    fun `deserializes article view recorded response`() {
        val raw = """
            {"ok":true,"data":{"recorded":true,"viewCount":43,"rateLimited":false}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ArticleViewResponse>>(raw)

        assertTrue(response.ok)
        assertEquals(true, response.data!!.recorded)
        assertEquals(43L, response.data!!.viewCount)
        assertEquals(false, response.data!!.rateLimited)
    }

    @Test
    fun `deserializes article view rate-limited response`() {
        // The backend returns 200 (not 429) with rateLimited=true when
        // the IP exceeds 60 requests/60s. Verify we handle it gracefully.
        val raw = """
            {"ok":true,"data":{"recorded":false,"viewCount":42,"rateLimited":true}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ArticleViewResponse>>(raw)

        assertTrue(response.ok)
        assertEquals(false, response.data!!.recorded)
        assertEquals(42L, response.data!!.viewCount)
        assertEquals(true, response.data!!.rateLimited)
    }

    @Test
    fun `deserializes article view duplicate response with missing rateLimited field`() {
        // rateLimited defaults to false — verify the default kicks in
        // when the field is missing.
        val raw = """
            {"ok":true,"data":{"recorded":false,"viewCount":42}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ArticleViewResponse>>(raw)

        assertTrue(response.ok)
        assertEquals(false, response.data!!.recorded)
        assertEquals(42L, response.data!!.viewCount)
        assertEquals(false, response.data!!.rateLimited)
    }

    // ── Related articles response ───────────────────────────────────────

    @Test
    fun `deserializes related articles response with reasons`() {
        val raw = """
            {"ok":true,"data":{"articles":[
                {"id":"a1","title":"Same author","excerpt":"...","coverImage":"https://example.com/1.png","videoUrl":null,"imageZoom":null,"imagePositionX":null,"imagePositionY":null,"publishedAt":"2026-09-01T00:00:00.000Z","readingTime":5,"author":{"id":"u1","fullName":"Alice","username":"alice","isVerified":true},"likeCount":10,"commentCount":2,"viewCount":100,"shareCount":1,"reason":"Same author"},
                {"id":"a2","title":"Trending","excerpt":null,"coverImage":null,"videoUrl":null,"publishedAt":"2026-10-01T00:00:00.000Z","readingTime":3,"author":{"id":"u2","fullName":"Bob","username":"bob","isVerified":false},"likeCount":50,"commentCount":10,"viewCount":500,"shareCount":5,"reason":"Trending"}
            ]}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<RelatedArticlesResponse>>(raw)

        assertTrue(response.ok)
        val articles = response.data!!.articles
        assertEquals(2, articles.size)
        assertEquals("Same author", articles[0].title)
        assertEquals("Same author", articles[0].reason)
        assertEquals(true, articles[0].author.isVerified)
        assertEquals("Trending", articles[1].reason)
        assertEquals(500L, articles[1].viewCount)
    }

    @Test
    fun `deserializes empty related articles response`() {
        // The backend returns an empty array (not error) when no
        // candidates are available. Verify we don't crash.
        val raw = """
            {"ok":true,"data":{"articles":[]}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<RelatedArticlesResponse>>(raw)

        assertTrue(response.ok)
        assertEquals(0, response.data!!.articles.size)
    }

    // ── Article translation response ───────────────────────────────────

    @Test
    fun `deserializes article translation response with RTL direction`() {
        val raw = """
            {"ok":true,"data":{"translation":{"articleId":"art-1","languageCode":"ar","translatedTitle":"العنوان","translatedDescription":"الوصف","translatedContent":"<p>المحتوى المترجم</p>","languageNativeName":"العربية","dir":"rtl","fromCache":false}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ArticleTranslationResponse>>(raw)

        assertTrue(response.ok)
        val t = response.data!!.translation
        assertEquals("art-1", t.articleId)
        assertEquals("ar", t.languageCode)
        assertEquals("العنوان", t.translatedTitle)
        // The translatedContent preserves the HTML structure (the backend's
        // translation prompt instructs the LLM to preserve HTML tags).
        assertEquals("<p>المحتوى المترجم</p>", t.translatedContent)
        assertEquals("العربية", t.languageNativeName)
        assertEquals("rtl", t.dir)
        assertEquals(false, t.fromCache)
    }

    @Test
    fun `deserializes cached article translation response`() {
        val raw = """
            {"ok":true,"data":{"translation":{"articleId":"art-1","languageCode":"fr","translatedTitle":"Titre","translatedDescription":null,"translatedContent":"<p>Contenu traduit</p>","languageNativeName":"Français","dir":"ltr","fromCache":true}}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ArticleTranslationResponse>>(raw)

        assertTrue(response.ok)
        val t = response.data!!.translation
        assertEquals("fr", t.languageCode)
        assertEquals("ltr", t.dir)
        assertEquals(true, t.fromCache)
        assertNull(t.translatedDescription)
    }

    // ── Article insights response ───────────────────────────────────────

    @Test
    fun `deserializes article insights response with metrics`() {
        val raw = """
            {"ok":true,"data":{"article":{"id":"art-1","title":"My article","excerpt":"...","publishedAt":"2026-08-09T23:39:20.253Z"},"metrics":{"uniqueViews":42,"likes":10,"comments":5,"shares":3,"engagementRate":42.9},"audience":{"followerViews":15,"nonFollowerViews":27,"followerPercentage":35.7,"nonFollowerPercentage":64.3},"trafficSources":null}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ArticleInsightsResponse>>(raw)

        assertTrue(response.ok)
        val data = response.data!!
        assertEquals("art-1", data.article.id)
        assertEquals("My article", data.article.title)
        assertEquals(42L, data.metrics.uniqueViews)
        assertEquals(10L, data.metrics.likes)
        assertEquals(5L, data.metrics.comments)
        assertEquals(3L, data.metrics.shares)
        assertEquals(42.9, data.metrics.engagementRate, 0.01)
        assertEquals(15L, data.audience.followerViews)
        assertEquals(27L, data.audience.nonFollowerViews)
        assertEquals(35.7, data.audience.followerPercentage, 0.01)
        assertEquals(64.3, data.audience.nonFollowerPercentage, 0.01)
        assertNull(data.trafficSources)
    }

    @Test
    fun `deserializes article insights empty response`() {
        // An article with no views/likes/comments — the backend returns
        // all-zero metrics. The UI shows the "No data yet" empty state.
        val raw = """
            {"ok":true,"data":{"article":{"id":"art-1","title":"New article","excerpt":null,"publishedAt":null},"metrics":{"uniqueViews":0,"likes":0,"comments":0,"shares":0,"engagementRate":0.0},"audience":{"followerViews":0,"nonFollowerViews":0,"followerPercentage":0.0,"nonFollowerPercentage":0.0},"trafficSources":null}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ArticleInsightsResponse>>(raw)

        assertTrue(response.ok)
        val data = response.data!!
        assertEquals(0L, data.metrics.uniqueViews)
        assertEquals(0.0, data.metrics.engagementRate, 0.001)
        assertEquals(0L, data.audience.followerViews)
    }

    // ── Article upsert body serialization ───────────────────────────────

    @Test
    fun `serializes article upsert body with all fields`() {
        val body = ArticleUpsertBody(
            title = "My article",
            content = "<p>Content</p>",
            excerpt = "Excerpt",
            coverImage = "https://example.com/img.png",
            videoUrl = null,
            status = "PUBLISHED",
            showCoverInArticle = true,
            topicIds = listOf("t1", "t2"),
        )

        val raw = json.encodeToString(ArticleUpsertBody.serializer(), body)

        // Verify the serialized JSON contains the expected fields.
        assertTrue(raw.contains("\"title\":\"My article\""))
        assertTrue(raw.contains("\"content\":\"<p>Content</p>\""))
        assertTrue(raw.contains("\"status\":\"PUBLISHED\""))
        assertTrue(raw.contains("\"topicIds\":[\"t1\",\"t2\"]"))
        // Null fields should be omitted (explicitNulls=false).
        assertFalse(raw.contains("\"videoUrl\""))
    }

    @Test
    fun `serializes article upsert body with only required fields`() {
        // For PATCH, only changed fields are sent. Verify a minimal body
        // serializes correctly (nulls omitted).
        val body = ArticleUpsertBody(
            title = "Updated title",
            content = null,
            excerpt = null,
            coverImage = null,
            videoUrl = null,
            status = null,
            showCoverInArticle = null,
            topicIds = null,
        )

        val raw = json.encodeToString(ArticleUpsertBody.serializer(), body)

        assertTrue(raw.contains("\"title\":\"Updated title\""))
        // All other fields should be omitted (nulls).
        assertFalse(raw.contains("\"content\""))
        assertFalse(raw.contains("\"status\""))
        assertFalse(raw.contains("\"topicIds\""))
    }

    // ── Error responses ─────────────────────────────────────────────────

    @Test
    fun `deserializes article forbidden error response`() {
        // Insights endpoint returns 403 when the viewer isn't the author.
        val raw = """
            {"ok":false,"error":{"message":"You can only view insights for your own articles"}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ArticleInsightsResponse>>(raw)

        assertFalse(response.ok)
        assertNull(response.data)
        assertEquals("You can only view insights for your own articles", response.error?.message)
    }

    @Test
    fun `deserializes article validation error response`() {
        // Create endpoint returns 400 when title/content validation fails.
        val raw = """
            {"ok":false,"error":{"message":"Title must be 3-200 characters"}}
        """.trimIndent()

        val response = json.decodeFromString<ApiResponse<ArticleUpsertResponse>>(raw)

        assertFalse(response.ok)
        assertNull(response.data)
        assertEquals("Title must be 3-200 characters", response.error?.message)
    }
}
